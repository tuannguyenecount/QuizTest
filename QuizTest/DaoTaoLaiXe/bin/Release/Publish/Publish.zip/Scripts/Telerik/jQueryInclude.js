var jQuery=window.jQuery=window.$=$telerik.$;
