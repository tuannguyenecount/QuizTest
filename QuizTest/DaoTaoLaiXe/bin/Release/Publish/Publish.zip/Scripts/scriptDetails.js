﻿
       //$(window).load(function () {
       //    $(".contentscroll").mCustomScrollbar({
       //        axis: "y",
       //        setHeight: "400",
       //        theme: "dark",
       //        scrollButtons: { enable: true }
       //    });
       //});
$(function () {
    $("#jblslider").jblSlider(
      {
          autoplay: true
      });
});